<?php

const API_KEY = '7643667218:AAHmIC7-FIN4DVHO-figdlsta_NQcsaS1Tc';
const RAMZINE = '947925:670026b59af4f';

$cryptoItems = [
    'نات کوین' => 'not',
    'نات'      => 'not',
    'تون کوین' => 'ton',
    'تون'      => 'ton',
    'تتر'      => 'usdt',
    'داگز'     => 'dogs',
    'شیبا'     => 'shib',
    'همستر'    => 'hmstr',
    'بیتکوین'  => 'btc',
    'بیت کوین' => 'btc',
    'بیت' => 'btc',
    'ترون'     => 'trx',
    'سولانا'    => 'sol',
    'فانتوم'   => 'ftm',
    'اتریوم'   => 'eth',
    'اتر'   => 'eth'
];